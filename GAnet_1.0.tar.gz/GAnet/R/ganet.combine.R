ganet.combine <- function(Bci=1,BIOGRID=1,HPRD=1,INTACT=1,MINT=1,UNIHI=0,IMID=0, CELL=0,NAT=0,REACT=0)
{
#databaseNames <- c("BCI","BioGrid","cell","hprd","UniHI","imid","intact","mint","nat","react")
CombinedDatabases <- c()
if(Bci==1)  {data(BCI); CombinedDatabases <- rbind(CombinedDatabases, BCI[,1:2]) }
if(BIOGRID ==1) {data(BioGrid); CombinedDatabases <- rbind(CombinedDatabases, BioGrid[,1:2]) }
if(HPRD ==1)  {data(hprd); CombinedDatabases <- rbind(CombinedDatabases, hprd[,1:2]) }
if(INTACT ==1)  {data(intact);CombinedDatabases <- rbind(CombinedDatabases, intact[,1:2]) }
if(MINT ==1)  {data(mint);CombinedDatabases <- rbind(CombinedDatabases, mint[,1:2]) }
#Automated literature-mining
if(UNIHI ==1)  {data(UniHI);CombinedDatabases <- rbind(CombinedDatabases, UniHI[,1:2]) }
#pathways are the followings
if(IMID ==1)  {data(imid);CombinedDatabases <- rbind(CombinedDatabases, imid[,1:2]) }
if(CELL ==1)  {data(cell);CombinedDatabases <- rbind(CombinedDatabases, cell[,1:2]) }
if(NAT ==1)  {data(nat);CombinedDatabases <- rbind(CombinedDatabases, nat[,1:2]) }
if(REACT ==1) {data(react); CombinedDatabases <- rbind(CombinedDatabases, react[,1:2]) }

CombinedDatabases <- ganet.UniqNetSimp(CombinedDatabases)
return(CombinedDatabases)
}
