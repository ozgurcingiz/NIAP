ganet.UniqNetSimp <- function(netlist)
{#1 and 2. columns are gene names and 3 is MI value, the rest is not important
#library(igraph)
i<-ncol(netlist)
if(i>2)
{
 x<-netlist[,1:3]
x<-na.omit(x)
g<-x[,1:2]
ge <- graph.data.frame(g, directed = FALSE)
ge <- set.edge.attribute(ge, "weight", value=as.numeric(x[,3]))
y<-simplify(ge)
yw <-get.edge.attribute(y, "weight")

MainNet <- get.edgelist(y)
MainNet <- cbind(MainNet,yw)

##
}else {
x<-netlist[,1:2]
x<-na.omit(x)
g<-x[,1:2]
ge <- graph.data.frame(g, directed = FALSE)
#ge <- set.edge.attribute(ge, "weight", value=as.numeric(x[,3]))
y<-simplify(ge)
#yw <-get.edge.attribute(y, "weight")

MainNet <- get.edgelist(y)
	
}

return(MainNet)
}
